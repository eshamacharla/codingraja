# CRT-INTERNSHIP-task2
Music Player using HTML, CSS, and JavaScript
